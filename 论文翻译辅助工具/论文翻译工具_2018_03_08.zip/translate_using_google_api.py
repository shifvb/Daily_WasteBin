import sys
import os

os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = "shifvb10-3303777117f2.json"

is_google_translate_loaded = True
try:
    from google.cloud import translate
except ImportError:
    translate = None
    is_google_translate_loaded = False
    print("[WARN] Google translate module missed. "
          'You can run "pip install google-cloud-translate" to install it', file=sys.stderr)


def translate_text(target, text):
    return translate.Client().translate(text, target_language=target)
