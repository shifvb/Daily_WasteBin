用来翻译paper的辅助工具
