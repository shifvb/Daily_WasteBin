import os
import hashlib


class MyFile(object):
    def __init__(self, path, hash_func):
        self.origin_abs_path = path  # 原文件绝对路径
        self.extension = os.path.splitext(path)[-1]  # 拓展名
        self.parent_folder = os.path.split(path)[0]  # 父文件夹
        self.new_abs_path = self.get_new_abs_path(hash_func)  # 新文件绝对路径

    def get_new_abs_path(self, hash_func):
        """获得新文件绝对路径"""
        m = hash_func()
        with open(self.origin_abs_path, 'rb') as f:
            for data in f:
                m.update(data)
        return os.path.join(self.parent_folder, m.hexdigest() + self.extension)


def test():
    f = MyFile(r"C:\Users\anonymous\Desktop\新建文件夹\dd.jpg", hashlib.md5)
    print(f.new_abs_path)


if __name__ == '__main__':
    test()
