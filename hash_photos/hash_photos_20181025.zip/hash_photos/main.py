from _gui.main_gui import HashPhotoApp

if __name__ == '__main__':
    HashPhotoApp()
