import os
import time
import hashlib
import shutil
import tkinter as tk
from tkinter import filedialog
from tkinter import messagebox
from tkinter.font import Font

from _gui.get_geometry import get_center_geometry
from _model.File import MyFile

__version__ = (1, 3, 2)


class HashPhotoApp(object):
    def __init__(self):
        self.root = tk.Tk()
        self.select_dir_entry_var = tk.StringVar()
        self.choose_hash_method_var = tk.IntVar(value=0)
        self.log_text_area_var = tk.StringVar()

        # 文件类型全局变量
        self.jpg_check_btn_var = tk.IntVar(value=1)
        self.png_check_btn_var = tk.IntVar(value=1)
        self.bmp_check_btn_var = tk.IntVar(value=1)
        self.gif_check_btn_var = tk.IntVar(value=1)

        self.big_font = Font(size=25, )
        self.mid_font = Font(size=16, )
        self.init_gui()
        tk.mainloop()

    def init_gui(self):
        self.root.geometry(get_center_geometry(self.root))
        self.root.title("hash photos v{}.{}.{}".format(*__version__))

        # 0. 选择要重命名图片/文件的文件夹
        select_dir_frame = tk.Frame(self.root)
        select_dir_frame.grid(row=0, column=0, columnspan=2)
        select_dir_entry = tk.Entry(select_dir_frame, width=49, textvariable=self.select_dir_entry_var)
        select_dir_entry.configure(font=self.mid_font)
        select_dir_entry.grid(row=0, column=0, padx=5)
        select_dir_btn = tk.Button(select_dir_frame, text="select dir", command=self.select_dir_btn_callback)
        select_dir_btn.configure(font=self.mid_font)
        select_dir_btn.grid(row=0, column=1)
        rename_btn = tk.Button(select_dir_frame, text="run", command=self.rename_file_btn_callback, width=9)
        rename_btn.config(font=self.mid_font)
        rename_btn.grid(row=0, column=2, padx=5)

        # 1. 选择哈希方法面板
        choose_hash_method_frame = tk.LabelFrame(self.root, text="choose hash method", font=self.mid_font)
        choose_hash_method_frame.grid(row=1, column=0, sticky=tk.W, padx=5)
        md5_radio_btn = tk.Radiobutton(choose_hash_method_frame, variable=self.choose_hash_method_var, value=0)
        md5_radio_btn.pack(side=tk.LEFT)
        md5_label = tk.Label(choose_hash_method_frame, text="md5", font=self.mid_font, )
        md5_label.bind("<Button-1>", lambda *args: self.choose_hash_method_var.set(0))
        md5_label.pack(side=tk.LEFT)
        sha1_radio_btn = tk.Radiobutton(choose_hash_method_frame, variable=self.choose_hash_method_var, value=1)
        sha1_radio_btn.pack(side=tk.LEFT)
        sha1_label = tk.Label(choose_hash_method_frame, text="sha1", font=self.mid_font)
        sha1_label.bind("<Button-1>", lambda *args: self.choose_hash_method_var.set(1))
        sha1_label.pack(side=tk.LEFT)
        sha256_radio_btn = tk.Radiobutton(choose_hash_method_frame, variable=self.choose_hash_method_var, value=2)
        sha256_radio_btn.pack(side=tk.LEFT)
        sha256_label = tk.Label(choose_hash_method_frame, text="sha256", font=self.mid_font)
        sha256_label.bind("<Button-1>", lambda *args: self.choose_hash_method_var.set(2))
        sha256_label.pack(side=tk.LEFT)
        sha512_radio_btn = tk.Radiobutton(choose_hash_method_frame, variable=self.choose_hash_method_var, value=3)
        sha512_radio_btn.pack(side=tk.LEFT)
        sha512_label = tk.Label(choose_hash_method_frame, text="sha512", font=self.mid_font)
        sha512_label.bind("<Button-1>", lambda *args: self.choose_hash_method_var.set(3))
        sha512_label.pack(side=tk.LEFT)

        # 2. 选择重命名文件类型面板
        choose_file_type_frame = tk.LabelFrame(self.root, text="choose file type", font=self.mid_font)
        choose_file_type_frame.grid(row=1, column=1, sticky=tk.E, padx=20)
        jpg_check_btn = tk.Checkbutton(choose_file_type_frame, variable=self.jpg_check_btn_var)
        jpg_check_btn.pack(side=tk.LEFT)
        jpg_label = tk.Label(choose_file_type_frame, text="jpg/jpeg", font=self.mid_font)
        jpg_label.bind("<Button-1>", lambda *args: self.jpg_check_btn_var.set(1 - self.jpg_check_btn_var.get()))
        jpg_label.pack(side=tk.LEFT)
        png_check_btn = tk.Checkbutton(choose_file_type_frame, variable=self.png_check_btn_var)
        png_check_btn.pack(side=tk.LEFT)
        png_label = tk.Label(choose_file_type_frame, text="png", font=self.mid_font)
        png_label.bind("<Button-1>", lambda *args: self.png_check_btn_var.set(1 - self.png_check_btn_var.get()))
        png_label.pack(side=tk.LEFT)
        bmp_check_btn = tk.Checkbutton(choose_file_type_frame, variable=self.bmp_check_btn_var)
        bmp_check_btn.pack(side=tk.LEFT)
        bmp_label = tk.Label(choose_file_type_frame, text="bmp", font=self.mid_font)
        bmp_label.bind("<Button-1>", lambda *args: self.bmp_check_btn_var.set(1 - self.bmp_check_btn_var.get()))
        bmp_label.pack(side=tk.LEFT)
        gif_check_btn = tk.Checkbutton(choose_file_type_frame, variable=self.gif_check_btn_var)
        gif_check_btn.pack(side=tk.LEFT)
        gif_label = tk.Label(choose_file_type_frame, text="gif", font=self.mid_font)
        gif_label.bind("<Button-1>", lambda *args: self.gif_check_btn_var.set(1 - self.gif_check_btn_var.get()))
        gif_label.pack(side=tk.LEFT)

        # 显示当前状态
        log_frame = tk.Frame(self.root)
        log_frame.grid(row=2, column=0, columnspan=2, sticky=tk.NSEW)
        self.log_text_area = tk.Text(log_frame, state=tk.DISABLED, width=70, height=23, font=self.mid_font)
        self.log_text_area.configure(wrap='none')
        self.log_text_area.grid(row=0, column=0, sticky=tk.NSEW)
        log_vert_scrollbar = tk.Scrollbar(log_frame)
        log_vert_scrollbar.grid(row=0, column=1, sticky=tk.NS)
        log_vert_scrollbar.configure(command=self.log_text_area.yview)
        self.log_text_area.configure(yscrollcommand=log_vert_scrollbar.set)
        log_hori_scorllbar = tk.Scrollbar(log_frame, orient=tk.HORIZONTAL)
        log_hori_scorllbar.grid(row=1, column=0, sticky=tk.EW)
        log_hori_scorllbar.configure(command=self.log_text_area.xview)
        self.log_text_area.configure(xscrollcommand=log_hori_scorllbar.set)

    def select_dir_btn_callback(self):
        """选择文件夹按钮回调函数"""
        self.select_dir_entry_var.set(filedialog.askdirectory())

    def _get_current_hash_func(self):
        """得到用户当前选定哈希函数类型"""
        _value = self.choose_hash_method_var.get()
        if _value == 0:
            m = hashlib.md5
        elif _value == 1:
            m = hashlib.sha1
        elif _value == 2:
            m = hashlib.sha256
        elif _value == 3:
            m = hashlib.sha512
        else:
            raise ValueError("Invalid hash type value: {}".format(_value))
        return m

    def _is_selected_file_type(self, abs_name: str) -> bool:
        """根据用户输入得到有效文件类型的字符串形式的列表"""
        valid_file_type_list = []
        if self.png_check_btn_var.get() == 1:
            valid_file_type_list.append(".png")
        if self.jpg_check_btn_var.get() == 1:
            valid_file_type_list.append(".jpg")
            valid_file_type_list.append(".jpeg")
        if self.bmp_check_btn_var.get() == 1:
            valid_file_type_list.append(".bmp")
        if self.gif_check_btn_var.get() == 1:
            valid_file_type_list.append(".gif")

        # 判断输入的绝对路径是不是想要重命名的文件
        if not os.path.exists(abs_name):  # 路径不存在返回False
            return False
        if not os.path.isfile(abs_name):  # 不是文件返回False
            return False
        return os.path.splitext(abs_name)[-1].lower() in valid_file_type_list  # 查看拓展名是不是选定的拓展名

    def move_file(self, origin_path: str):
        """
        将文件移动到 ./backup/{time} 目录下
        :param origin_path: 原文件绝对路径
        """
        _workspace, _filename = os.path.split(origin_path)
        # 创建备份目录./backup/{time}
        _time_str = "{:02}_{:02}_{:02} {:02}_{:02}_{:02}".format(*time.localtime())
        new_path = os.path.join(_workspace, "backup")
        if not os.path.exists(new_path):
            os.mkdir(new_path)
        new_path = os.path.join(new_path, _time_str)
        if not os.path.exists(new_path):
            os.mkdir(new_path)

        # 移动文件
        shutil.move(origin_path, os.path.join(new_path, _filename))

    def rename_file_btn_callback(self):
        """重命名按钮回调函数"""
        _workspace = self.select_dir_entry_var.get()
        # 如果没有选定就直接结束callback
        if _workspace == "":
            messagebox.showinfo(title="info", message="Please choose directory!")
            return
        # 如果文件夹不存在报错
        if not os.path.isdir(_workspace):
            messagebox.showerror(title="error", text="Directory\n{}\nnot exists!")
            return
        # 置为可修改状态
        self.log_text_area.configure(state=tk.NORMAL)
        self.log_text_area.insert(tk.END, "[{}] rename started\n".format(time.asctime()))
        # 得到需要重命名的文件列表
        abs_names = [os.path.join(_workspace, _) for _ in os.listdir(_workspace)]
        abs_file_names = [_ for _ in abs_names if self._is_selected_file_type(_)]
        file_list = [MyFile(_, self._get_current_hash_func()) for _ in abs_file_names]
        # 创建当前已重命名文件名集合，追踪当前文件夹中文件状态
        temp_new_name_set = set()
        # 开始重命名
        for file in file_list:
            # 如果计算出的新文件名和旧文件名相同，跳过
            if file.origin_abs_path == file.new_abs_path:
                self.log_text_area.insert(tk.END, "[INFO] 已重命名过，跳过({})\n".format(file.origin_abs_path))
                continue
            # 如果计算出的新文件名和旧文件名相同，但是新文件名已存在，将此文件移动到 ./backup/{time} 目录下
            if file.new_abs_path in temp_new_name_set:
                self.log_text_area.insert(tk.END, "[WARN] 文件名经存在，跳过并移入备份文件夹({})\n".format(file.origin_abs_path))
                self.move_file(file.origin_abs_path)
                continue
            try:  # 如果一切条件都正常，那么就开始重命名
                os.rename(file.origin_abs_path, file.new_abs_path)
                temp_new_name_set.add(file.new_abs_path)
                self.log_text_area.insert(
                    tk.END, "[INFO] 重命名：{} -> {}\n".format(file.origin_abs_path, file.new_abs_path)
                )
            except IOError as err:
                self.log_text_area.insert(tk.END, "[ERROR] {}\n".format(err))

        # 置为不可修改状态
        self.log_text_area.configure(state=tk.DISABLED)
