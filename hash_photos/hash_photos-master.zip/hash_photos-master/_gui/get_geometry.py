import tkinter as tk

_1080P = (1920, 1080)
_2K = (2560, 1440)
_4K = (3840, 2160)


def get_center_geometry(p_root: tk.Tk):
    """根据屏幕分辨率确定一个合适的窗口大小，并在屏幕中心居中"""
    screen_resolution = p_root.winfo_screenwidth(), p_root.winfo_screenheight()

    if screen_resolution[1] == _1080P[1]:
        window_resolution = (800, 600)
    else:
        # 其它分辨率, 最小800x600， 最大4K， 非标准屏幕就全屏
        if screen_resolution[0] < _1080P[0] and screen_resolution[1] < _1080P[1]:
            window_resolution = (800, 600)
        elif screen_resolution[0] > _4K[0] and screen_resolution[1] > _4K[1]:
            window_resolution = _4K
        else:
            window_resolution = screen_resolution

    return "{}x{}+{}+{}".format(*window_resolution,
                                int((screen_resolution[0] - window_resolution[0]) / 2),
                                int((screen_resolution[1] - window_resolution[1]) / 2))


if __name__ == '__main__':
    root = tk.Tk()
    g = get_center_geometry(root)
    root.geometry(g)
    root.mainloop()
