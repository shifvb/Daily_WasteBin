# hash_photos
将给定文件夹里的图片重命名成其md5值
# only work at python3.3+
