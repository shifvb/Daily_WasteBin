import shutil
import time
import os


def move_file(origin_path: str):
    """
    将文件移动到 ./backup/{time} 目录下
    :param origin_path: 原文件绝对路径
    """

    _workspace, _filename = os.path.split(origin_path)

    # 创建备份目录./backup/{time}
    _time_str = "{:02}_{:02}_{:02} {:02}_{:02}_{:02}".format(*time.localtime())
    new_path = os.path.join(_workspace, "backup")
    if not os.path.exists(new_path):
        os.mkdir(new_path)
    new_path = os.path.join(new_path, _time_str)
    if not os.path.exists(new_path):
        os.mkdir(new_path)

    # 移动文件
    shutil.move(origin_path, os.path.join(new_path, _filename))
