import os


def is_vaild_file(instance, abs_name: str) -> bool:
    # 根据用户输入得到有效文件类型的字符串形式的列表
    valid_file_type_list = []
    if instance.png_check_btn_var.get() == 1:
        valid_file_type_list.append(".png")
    if instance.jpg_check_btn_var.get() == 1:
        valid_file_type_list.append(".jpg")
        valid_file_type_list.append(".jpeg")
    if instance.bmp_check_btn_var.get() == 1:
        valid_file_type_list.append(".bmp")
    if instance.gif_check_btn_var.get() == 1:
        valid_file_type_list.append(".gif")

    # 判断输入的绝对路径是不是想要重命名的文件
    if not os.path.exists(abs_name):  # 路径不存在返回False
        return False
    if not os.path.isfile(abs_name):  # 不是文件返回False
        return False
    if os.path.splitext(abs_name)[1].lower() not in valid_file_type_list:  # 查看拓展名是不是感兴趣拓展名
        return False
    return True
