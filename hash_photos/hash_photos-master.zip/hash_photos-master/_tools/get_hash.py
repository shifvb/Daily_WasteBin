import hashlib


def get_hash(instance, abs_filename: str):
    """
    得到特定文件十六进制哈希值
    :param instance:
    :param abs_filename: 文件绝对路径
    :return: 十六进制哈希值字符串
    """
    _value = instance.choose_hash_method_var.get()
    m = None
    if _value == 0:
        m = hashlib.md5()
    elif _value == 1:
        m = hashlib.sha1()
    elif _value == 2:
        m = hashlib.sha256()
    elif _value == 3:
        m = hashlib.sha512()
    with open(abs_filename, 'rb') as f:
        for data in f:
            m.update(data)
    return m.hexdigest()
